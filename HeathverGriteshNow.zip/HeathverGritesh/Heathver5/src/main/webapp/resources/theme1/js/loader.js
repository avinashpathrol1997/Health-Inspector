var myVar;

function myFunction() {
  myVar = setTimeout(showPage, 2000);
}

function showPage() {
  document.getElementById("loader").style.display = "none";
  document.getElementById("myDiv").style.display = "block";
}


/*************************************************************************VALIDATION**************************************************************************/

function form4() {
    var fname = document.getElementById("fname4");
    var lname = document.getElementById("lname4");
	var specialization = document.getElementById("specialization4");
	var practice = document.getElementById("practice4");
	var clinic = document.getElementById("clinic4");
	var contact = document.getElementById("contact4");
	var email = document.getElementById("email4");
	var uname = document.getElementById("name4");
	var pwd = document.getElementById("pwd4");
	
	 var letters = /^[A-Za-z]+$/;
	
	/******FIRSTNAME******/
	
	if(fname.value == ""){
		alert("Firstname should not be empty.");
		fname.focus();
		return false;
	}
	else if(!(fname.value.match(letters))){
		alert("Firstname must only contain letters.");
		fname.focus();
		return false;
	}
	
	
	/******LASTNAME******/
	
	if(lname.value == ""){
		alert("Lastname should not be empty.");
		lname.focus();
		return false;
	}
	else if(!(lname.value.match(letters))){
		alert("Lastname must only contain letters.");
		lname.focus();
		return false;
	}
	
	
		/******SPECIALIZATION******/
	
	if(specialization.value == ""){
		alert("Specialization should not be empty.");
		specialization.focus();
		return false;
	}
	else if(!(specialization.value.match(letters))){
		alert("Specialization must only contain letters.");
		specialization.focus();
		return false;
	}
	
		
		/******PRACTICE******/
	
	if(practice.value == ""){
		alert("Practice should not be empty.");
		practice.focus();
		return false;
	}
	else if(!(practice.value.match(letters))){
		alert("Practice must only contain letters.");
		practice.focus();
		return false;
	}
		
		
		/******CLINIC******/
	
	if(clinic.value == ""){
		alert("Clinic should not be empty.");
		clinic.focus();
		return false;
	}
	else if(!(clinic.value.match(letters))){
		alert("Clinic must only contain letters.");
		clinic.focus();
		return false;
	}
    
    return true;
}