package com.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.pojo.User;

import com.service.RegistrationService;

@Controller
@RequestMapping("/user")
public class RegistrationControl {

	@Autowired
	private RegistrationService registrationService;	

	
	private static Logger log = Logger.getLogger(RegistrationControl.class);


	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public ModelAndView validateUsr(@RequestParam("username")String username,@RequestParam("password")String password,@RequestParam("firstName")String firstName,@RequestParam("lastName")String lastName,@RequestParam("mobile")String mobile,@RequestParam("email")String email,@RequestParam("age")int age,@RequestParam("gender")String gender) {
		String msg = "";
		
		
        User user=new User();
        user.setFirstName(firstName);
        user.setLastName(lastName);
        user.setMobile(mobile);
        user.setEmail(email);
        user.setAge(age);
        user.setGender(gender);
        user.setName(username);
        user.setPassword(password);
        boolean isValid = registrationService.registerUser(user);
        log.info("Is user valid?= " + isValid);
        
        
		
		if(isValid) {
			msg = "Registration success for " + username + "!";
		} else {
			msg = "Invalid credentials";
		}

		return new ModelAndView("index", "output", msg);
	}
}